import boto3
import csv

# Define o nome do bucket S3 e o nome do arquivo CSV
s3_bucket_name = 'etl-marvel-bucket'
s3_file_name = 'marvel.csv'

# Define o nome da tabela DynamoDB
dynamodb_table_name = 'marveldb'

# Cria uma conexão com o serviço S3
s3 = boto3.client('s3')

# Cria uma conexão com o serviço DynamoDB
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(dynamodb_table_name)

def lambda_handler(event, context):
    # Lê o arquivo CSV do bucket S3
    response = s3.get_object(Bucket=s3_bucket_name, Key=s3_file_name)
    csv_content = response['Body'].read().decode('utf-8')

    # Faz o parsing do arquivo CSV
    csv_reader = csv.DictReader(csv_content.splitlines())

    # Loop através de cada linha do arquivo CSV
    for row in csv_reader:
        # Faz a transformação dos campos
        item = {
            'id_': row['id_'],
            'image': row['Imagem'] if row['Imagem'] else 'none',
            'name': row['Nome'] if row['Nome'] else 'none',
            'description': row['Descrição'] if row['Descrição'] else 'none'
        }

        # Insere o item na tabela DynamoDB
        table.put_item(Item=item)
    
    return {
        'statusCode': 200,
        'body': 'Dados carregados com sucesso!'
    }
